package com.example.didit_crudmysql.Model;

import com.google.gson.annotations.SerializedName;

public class Food {

    @SerializedName("id")
    private String id;
    @SerializedName("name")
    private String name;
    @SerializedName("description")
    private String description;
    @SerializedName("harga")
    private String harga;
    @SerializedName("image")
    private String image;

    public Food(){}

    public Food(String id, String name, String description, String harga, String image) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.harga = harga;
        this.image = image;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

}
