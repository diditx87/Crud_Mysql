package com.example.didit_crudmysql.Model;

import com.google.gson.annotations.SerializedName;

public class PostPutDelFood {
    @SerializedName("status")
    String status;
    @SerializedName("result")
    Food mFood;
    @SerializedName("message")
    String message;
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public Food getFood() {
        return mFood;
    }
    public void setFood(Food Food) {
        mFood = Food;
    }

}
