package com.example.didit_crudmysql.Adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.didit_crudmysql.Activity.EditActivity;
import com.example.didit_crudmysql.Config;
import com.example.didit_crudmysql.Model.Food;
import com.example.didit_crudmysql.R;

import java.util.List;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.MyViewHolder>{
    List<Food> mFoodList;

    public FoodAdapter(List<Food> FoodList) {
        mFoodList = FoodList;
    }

    @Override
    public MyViewHolder onCreateViewHolder (ViewGroup parent, int viewType){
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_food, parent, false);
        MyViewHolder mViewHolder = new MyViewHolder(mView);
        return mViewHolder;
    }

    @Override
    public void onBindViewHolder (MyViewHolder holder,final int position){
        holder.mTextViewName.setText(mFoodList.get(position).getName());
        holder.mTextViewDescription.setText(mFoodList.get(position).getDescription());
        holder.mTextViewHarga.setText(mFoodList.get(position).getHarga());
        Glide.with(holder.itemView.getContext())
                .load(Config.IMAGES_URL + mFoodList.get(position).getImage())
                .apply(new RequestOptions().override(350, 550))
                .into(holder.mImageViewFoto);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(view.getContext(), EditActivity.class);
                mIntent.putExtra("Id", mFoodList.get(position).getId());
                mIntent.putExtra("Name", mFoodList.get(position).getName());
                mIntent.putExtra("Description", mFoodList.get(position).getDescription());
                mIntent.putExtra("Harga", mFoodList.get(position).getHarga());
                mIntent.putExtra("Image", mFoodList.get(position).getImage());
                view.getContext().startActivity(mIntent);
            }
        });
    }

    @Override
    public int getItemCount () {
        return mFoodList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView mTextViewName, mTextViewDescription, mTextViewHarga;
        public ImageView mImageViewFoto;

        public MyViewHolder(View itemView) {
            super(itemView);
            mTextViewName = (TextView) itemView.findViewById(R.id.tv_item_name);
            mTextViewDescription = (TextView) itemView.findViewById(R.id.tv_item_description);
            mTextViewHarga = (TextView) itemView.findViewById(R.id.tv_item_harga);
            mImageViewFoto = itemView.findViewById(R.id.img_item_photo);
        }
    }
}

